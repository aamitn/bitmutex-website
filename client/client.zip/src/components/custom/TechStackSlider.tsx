"use client";

import React from "react";
import Image from "next/image";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import { Autoplay } from "swiper/modules";

const STRAPI_BASE_URL = process.env.NEXT_PUBLIC_STRAPI_BASE_URL || "http://localhost:1337";

export default function TechStackSlider({ logos }: { logos: { url: string }[] }) {
  return (
    <div className="relative py-10 bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">


      <div className="relative overflow-hidden px-4">
        <Swiper
          modules={[Autoplay]}
          spaceBetween={10} // Reduce space to prevent gaps
          slidesPerView={3} // Fixed number prevents gaps
          loop={true}
          autoplay={{ delay: 0, disableOnInteraction: false }}
          speed={1000} // Smooth infinite scroll
          breakpoints={{
            640: { slidesPerView: 3 },
            1024: { slidesPerView: 4 },
            1280: { slidesPerView: 5 },
          }}
          className="w-full"
        >
          {logos.map((logo, i) => (
            <SwiperSlide key={i} className="w-full flex justify-center">
              <div className="w-[120px] h-[80px] flex items-center justify-center bg-white/80 dark:bg-black/90 backdrop-blur-lg shadow-md rounded-lg border border-gray-200 dark:border-gray-700  hover:scale-105 transition-transform">
                <Image
                  src={`${STRAPI_BASE_URL}${logo.url}`}
                  alt={`Tech logo ${i}`}
                  width={100}
                  height={60}
                  className="object-contain h-[60px]"
                />
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>

      <style jsx>{`
        .relative {
          mask-image: linear-gradient(to right, transparent 0%, white 10%, white 90%, transparent 100%);
        }
      `}</style>
    </div>
  );
}
