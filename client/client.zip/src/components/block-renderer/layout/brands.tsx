"use client";

import { useEffect, useRef } from "react";
import Image from "next/image";
import { motion, useAnimation, useInView } from "framer-motion";
import { strapiImage } from "@/lib/strapi/strapiImage";
import { Card, CardContent } from "@/components/ui/card";
import { Heading } from "../../elements/heading";
import { Subheading } from "../../elements/subheading";
import { BrandsProps } from "@/types";


export function Brands(data: Readonly<BrandsProps>) {
  const { heading, sub_heading, logos } = data;
  const speed = 5; // Adjustable speed (seconds per loop)
  const easing = "easeInOut"; // Adjustable easing function
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: false });
  const controls = useAnimation();

  useEffect(() => {
    if (isInView) {
      controls.start({
        x: ["0%", "-100%"],
        transition: { ease: easing, duration: speed, repeat: Infinity, repeatType: "loop" },
      });
    }
  }, [controls, speed, easing, isInView]);

  return (
    <div className="relative py-10 md:py-40 overflow-hidden bg-transparent">
      <Heading className="pt-4 text-cyan-950 dark:text-slate-300">{heading}</Heading>
      <Subheading className="max-w-3xl mx-auto text-cyan-950 dark:text-slate-300">{sub_heading}</Subheading>

      {/* Infinite Scrolling Carousel */}
      <div ref={containerRef} className="relative w-full overflow-hidden mt-10">
        <motion.div
          className="flex space-x-10 md:space-x-16 items-center w-max"
          animate={controls}
          onMouseEnter={() => controls.stop()} // Pause on hover
          onMouseLeave={() =>
            controls.start({
              x: ["0%", "-100%"],
              transition: { ease: easing, duration: speed, repeat: Infinity, repeatType: "loop" },
            })
          }
        >
          {/* Duplicate Logos for Seamless Infinite Scrolling */}
          {[...logos, ...logos, ...logos].map((logo, idx) => (
            
            <motion.div
              key={idx}
              className="h-14 md:h-20 flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 2 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="border-none bg-transparent shadow-none">
                <CardContent className="p-2 flex items-center">
                  <Image
                  
                    src={strapiImage(logo.image.url)}
                    alt={logo.company}
                    width={140}
                    height={140}
                    className="h-full w-auto object-contain"
                  />
                </CardContent>
              </Card>
            </motion.div>
          ))}

        </motion.div>
        
      </div>
    </div>
  );
};