import { SigninForm } from "@/components/forms/sign-in-form";

export default function SignInRoute() {
  return <SigninForm />;
}